package com.bankapp.admin_service.enumes;

public enum AccountStatus {
	ACTIVATED, SUSPENDED
}
