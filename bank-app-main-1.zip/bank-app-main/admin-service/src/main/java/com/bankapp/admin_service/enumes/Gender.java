package com.bankapp.admin_service.enumes;

public enum Gender {
	M,F
}
