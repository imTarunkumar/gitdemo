package com.bankapp.customer_service.enumes;

public enum LoanStatus {
	APPROVED, REJECTED, INPROGRESS, OPEN, CLOSED
}
