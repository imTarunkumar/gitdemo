package com.bankapp.customer_service.enumes;

public enum TransactionType {
	DEPOSIT, WITHDRAW, TRANSFER, INVESTMENT
}
