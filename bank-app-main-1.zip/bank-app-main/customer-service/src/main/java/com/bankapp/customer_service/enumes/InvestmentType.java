package com.bankapp.customer_service.enumes;

public enum InvestmentType {
	LOAN, RECURRING_DEPOSIT, FIXED_DEPOSITS
}
