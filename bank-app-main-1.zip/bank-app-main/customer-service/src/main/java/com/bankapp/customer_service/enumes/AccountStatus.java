package com.bankapp.customer_service.enumes;

public enum AccountStatus {
	ACTIVATED, SUSPENDED
}
