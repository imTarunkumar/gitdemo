package com.bankapp.customer_service.dto;

public class LoanCalculatorResponse {
	private Integer emi;

	public Integer getEmi() {
		return emi;
	}

	public void setEmi(Integer emi) {
		this.emi = emi;
	}
}
