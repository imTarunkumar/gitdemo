package com.bankapp.customer_service.enumes;

public enum ERole {
    ROLE_USER,ROLE_ADMIN
}